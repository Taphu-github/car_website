
// Header
let header = document.querySelector('header');
window.addEventListener('scroll', () => {
    header.classList.toggle('shadow', window.scrollY > 0);
}); 

function searchCar() {
    event.preventDefault();
    let searchVal = document.getElementById('searchvalue').value.split(',').map(val => val.trim()); // usa, china    ,=>['usa', 'bmw'] car{mode: bmw, lcoation: usa}

    let filterVal = document.getElementById('carscontainer');
    document.getElementById('home').style.display = "none";

    let outputVal = document.getElementById('searchdisplay');
    outputVal.innerHTML = "";

    let hrline = document.createElement('hr');
    let addedElements = new Set(); // To track added elements
    //searchVal=['usa','bmw']
    //searchVal.length=2. 0->'usa' 1->'bmw'
    //j++, j+1
    //continue : codes below the code will be skipped, goes to next iteration if its there
    //break : gets out of the parent for loop

    for (let j = 0; j < searchVal.length; j++) {

        if (searchVal[j] === '') {//'usa'==='' : False
            continue;
        }


        for (let i = 0; i < filterVal.children.length; i++) {
            
            let child = filterVal.children[i];
            let modelText = child.children[2].textContent.toLowerCase();
            let locationText = child.children[3].textContent.toLowerCase();
            let searchTerm = searchVal[j].toLowerCase();//'USA'->'usa' 'Usa'->'usa'
            //string.includes(substring): checks if the substring is present in the string. returns true if it does otherwise false
            // || : or (True or False)

            if (modelText.includes(searchTerm) || locationText.includes(searchTerm)) {

                if (!addedElements.has(child)) {
                    addedElements.add(child);
                    outputVal.appendChild(child.cloneNode(true)); // Clone the node to avoid moving it
                    outputVal.appendChild(hrline.cloneNode(true));
                }
            }
        }

    }

    if (outputVal.children.length === 0) {
        document.getElementById('home').style.display = "flex";
    }
}


//In JavaScript, a Set is a built-in object that represents a collection of unique values. Unlike arrays, 
//Set objects automatically ensure that each value is unique and do not allow duplicate values. 
//This makes Set particularly useful for operations where you need to maintain a collection of unique items, 
//such as tracking unique items or eliminating duplicates.