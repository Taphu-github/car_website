const inputs = document.querySelectorAll('input');

inputs.forEach(input => {
    input.addEventListener('focus', function () {
        input.style.backgroundColor = 'yellow'; 
    });

    input.addEventListener('blur', function () {
        input.style.backgroundColor = 'white'; 
    });
});

const buttons = document.querySelectorAll('button');

buttons.forEach(button => {
    button.addEventListener('mouseenter', function () {
        button.style.backgroundColor = 'lightblue'; 
    });

    button.addEventListener('mouseleave', function () {
        button.style.backgroundColor = 'white'; 
    });
});