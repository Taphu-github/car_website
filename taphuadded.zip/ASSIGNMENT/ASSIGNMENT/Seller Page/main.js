function validateLoginForm(){
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    window.open('../Seller Page/addcar.html')
}


