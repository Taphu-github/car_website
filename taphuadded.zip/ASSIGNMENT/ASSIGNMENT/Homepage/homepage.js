
// Header
let header = document.querySelector('header');
window.addEventListener('scroll', () => {
    header.classList.toggle('shadow', window.scrollY > 0);
}); 

function searchCar(){
    event.preventDefault();
    let searchVal= document.getElementById('searchvalue').value.split(',');
    console.log(searchVal);
    let filterVal=document.getElementById('carscontainer');
    document.getElementById('home').style.display="None";

    let outputVal=document.getElementById('searchdisplay');
    document.getElementById('searchdisplay').innerHTML="";
    let hrline = document.createElement('hr');


    for(let j=0; j<searchVal.length; j++){
        console.log(searchVal[j]);
        for (let i=0; i<filterVal.children.length; i++){
            let child = filterVal.children[i];
            console.log(child.children[2].textContent);
            if (child.children[2].textContent.includes(searchVal[j]) || child.children[3].textContent.includes(searchVal[j])) {
                console.log(child); // Log the matching element
                outputVal.appendChild(child.cloneNode(true)); // Clone the node to avoid moving it
                outputVal.appendChild(hrline.cloneNode(true));
            }
            
        }
    }

    if(outputVal.children.length==0){
        document.getElementById('home').style.display="flex";
        console.log('yes');
    };

     

    
   
    //const postsContainer = document.querySelector(".cars-container");
}
